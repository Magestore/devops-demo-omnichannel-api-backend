# for now fetch the development settings only
import os
from dev import *

ALLOWED_HOSTS=[u'23.236.59.109']

LANGUAGE_CODE = 'en'
TIME_ZONE = 'Etc/UTC'

BASE_DIR = '/data/python-project/django/project'

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.path.join(BASE_DIR, 'db.sqlite3')
    }
}

